
const imgOriginal = 'gatodormindo.png';
const imgHover = 'gatofeliz.png';
 const imgClique = 'gatotriste.png';

 // 1. Mudar ao passar o mouse
function passarMouse(element) {
    element.src = imgHover;
}

// 2. Voltar ao tirar o mouse
function tirarMouse(element) {
    element.src = imgOriginal;
}

// 3. Mudar ao clicar
function clicarImagem(element) {
    element.src = imgClique;
            
    // Opcional: Remover eventos de hover após clicar
    element.onmouseover = null;
    element.onmouseout = null;
}