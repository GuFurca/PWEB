let eventos = require('events'); //Atribuicao da classe EventEmiter a uma variável
let EmissorEventos = eventos.EventEmitter;
//O emissorde eventos, encontra-se na propriedade EventEmitter
let ee = new EmissorEventos();
//ou criando direto sem a variável intermediaria
//let ee = new eventos.EventEmitter();
//mas da forma anterior é uma boa prática

//É registrado um ouvinte (listener) para o evento 'dados'.
//Quando esse evento acontecer executar a função passado como argumento
ee.on('dados', function(fecha){
    console.log(fecha);
})
//Emissão de eventos somente uma vez
ee.emit('dados', 'primeira vez' + Date.now());

//Emissão do evento a cada 500 milisegundos
setInterval(function(){
    ee.emit('dados', Date.now());
}, 500)